package com.baizhi.springboot_jsp_shiro;

import java.util.HashMap;

public class TestHashMap {

    public static void main(String[] args) {

        HashMap<String, String> hash = new HashMap<>();

        hash.put("aa","xxx");


    }
}
